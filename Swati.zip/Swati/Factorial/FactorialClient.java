import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

public class FactorialClient {

    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost");
            FactorialService factorialService = (FactorialService) registry.lookup("FactorialService");

            Scanner scanner = new Scanner(System.in);

            System.out.print("Enter a number: ");
            int number = scanner.nextInt();

            int factorial = factorialService.calculateFactorial(number);
            System.out.println("Factorial of " + number + " is: " + factorial);
        } catch (Exception e) {
            System.err.println("Factorial Client exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
