import java.rmi.Remote;
import java.rmi.RemoteException;

public interface PalindromeService extends Remote {
    boolean isPalindrome(String word) throws RemoteException;
}
