import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class PalindromeClient {

    public static void main(String[] args) {
        try {
            Registry registry = LocateRegistry.getRegistry("localhost");
            PalindromeService palindromeService = (PalindromeService) registry.lookup("PalindromeService");

            String word = "level";
            boolean isPalindrome = palindromeService.isPalindrome(word);

            System.out.println("Is '" + word + "' a palindrome? " + isPalindrome);
        } catch (Exception e) {
            System.err.println("Palindrome Client exception: " + e.toString());
            e.printStackTrace();
        }
    }
}
